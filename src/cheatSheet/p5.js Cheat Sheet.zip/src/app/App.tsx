import { P5CheatSheet } from "./components/P5CheatSheet";

export default function App() {
  return (
    <div className="size-full flex items-center justify-center">
      <P5CheatSheet />
    </div>
  );
}