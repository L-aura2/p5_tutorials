'use client';

import { useState } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Search, FileDown } from 'lucide-react';

interface FunctionItem {
  name: string;
  syntax: string;
  description: string;
  example?: string;
}

interface Category {
  title: string;
  functions: FunctionItem[];
}

const cheatSheetData: Category[] = [
  {
    title: "Structure",
    functions: [
      {
        name: "setup()",
        syntax: "function setup() { }",
        description: "Called once when the program starts. Used to initialize variables, create canvas, load media, etc.",
        example: "function setup() {\n  createCanvas(400, 400);\n}"
      },
      {
        name: "draw()",
        syntax: "function draw() { }",
        description: "Called repeatedly, executes code within it. Used for animation.",
        example: "function draw() {\n  background(220);\n  ellipse(50, 50, 80);\n}"
      },
      {
        name: "preload()",
        syntax: "function preload() { }",
        description: "Called before setup(). Used to load external files like images, fonts, sounds.",
        example: "function preload() {\n  img = loadImage('pic.jpg');\n}"
      }
    ]
  },
  {
    title: "Environment",
    functions: [
      {
        name: "createCanvas()",
        syntax: "createCanvas(width, height)",
        description: "Creates a canvas element with specified width and height in pixels.",
        example: "createCanvas(800, 600);"
      },
      {
        name: "frameRate()",
        syntax: "frameRate(fps)",
        description: "Specifies the number of frames to be displayed every second.",
        example: "frameRate(30);"
      },
      {
        name: "width",
        syntax: "width",
        description: "System variable that stores the width of the canvas.",
        example: "let x = width / 2;"
      },
      {
        name: "height",
        syntax: "height",
        description: "System variable that stores the height of the canvas.",
        example: "let y = height / 2;"
      },
      {
        name: "frameCount",
        syntax: "frameCount",
        description: "Contains the number of frames displayed since program started.",
        example: "text(frameCount, 10, 10);"
      }
    ]
  },
  {
    title: "Shapes - 2D Primitives",
    functions: [
      {
        name: "ellipse()",
        syntax: "ellipse(x, y, w, h)",
        description: "Draws an ellipse at (x, y) with width w and height h.",
        example: "ellipse(50, 50, 80, 80);"
      },
      {
        name: "circle()",
        syntax: "circle(x, y, d)",
        description: "Draws a circle at (x, y) with diameter d.",
        example: "circle(50, 50, 80);"
      },
      {
        name: "rect()",
        syntax: "rect(x, y, w, h)",
        description: "Draws a rectangle at (x, y) with width w and height h.",
        example: "rect(30, 20, 55, 55);"
      },
      {
        name: "square()",
        syntax: "square(x, y, s)",
        description: "Draws a square at (x, y) with side length s.",
        example: "square(30, 20, 55);"
      },
      {
        name: "triangle()",
        syntax: "triangle(x1, y1, x2, y2, x3, y3)",
        description: "Draws a triangle with vertices at specified coordinates.",
        example: "triangle(30, 75, 58, 20, 86, 75);"
      },
      {
        name: "line()",
        syntax: "line(x1, y1, x2, y2)",
        description: "Draws a line between two points.",
        example: "line(30, 20, 85, 75);"
      },
      {
        name: "point()",
        syntax: "point(x, y)",
        description: "Draws a point at coordinate (x, y).",
        example: "point(50, 50);"
      },
      {
        name: "quad()",
        syntax: "quad(x1, y1, x2, y2, x3, y3, x4, y4)",
        description: "Draws a quadrilateral with four vertices.",
        example: "quad(38, 31, 86, 20, 69, 63, 30, 76);"
      },
      {
        name: "arc()",
        syntax: "arc(x, y, w, h, start, stop)",
        description: "Draws an arc at (x, y) from start angle to stop angle.",
        example: "arc(50, 55, 50, 50, 0, HALF_PI);"
      }
    ]
  },
  {
    title: "Color",
    functions: [
      {
        name: "background()",
        syntax: "background(color)",
        description: "Sets the color used for the background of the canvas.",
        example: "background(255, 204, 0);"
      },
      {
        name: "fill()",
        syntax: "fill(color)",
        description: "Sets the color used to fill shapes.",
        example: "fill(255, 0, 0);"
      },
      {
        name: "noFill()",
        syntax: "noFill()",
        description: "Disables filling geometry.",
        example: "noFill();\nrect(10, 10, 50, 50);"
      },
      {
        name: "stroke()",
        syntax: "stroke(color)",
        description: "Sets the color used to draw lines and borders around shapes.",
        example: "stroke(255, 0, 0);"
      },
      {
        name: "noStroke()",
        syntax: "noStroke()",
        description: "Disables drawing the stroke (outline).",
        example: "noStroke();\nellipse(50, 50, 80);"
      },
      {
        name: "strokeWeight()",
        syntax: "strokeWeight(weight)",
        description: "Sets the width of the stroke used for lines and borders.",
        example: "strokeWeight(4);"
      },
      {
        name: "color()",
        syntax: "color(r, g, b, a)",
        description: "Creates colors for storing in variables of the color datatype.",
        example: "let c = color(255, 0, 0);"
      },
      {
        name: "colorMode()",
        syntax: "colorMode(mode, max)",
        description: "Changes the way p5.js interprets color data (RGB or HSB).",
        example: "colorMode(HSB, 360, 100, 100);"
      }
    ]
  },
  {
    title: "Transform",
    functions: [
      {
        name: "translate()",
        syntax: "translate(x, y)",
        description: "Displaces objects by specified x and y values.",
        example: "translate(50, 50);"
      },
      {
        name: "rotate()",
        syntax: "rotate(angle)",
        description: "Rotates objects by specified angle (in radians).",
        example: "rotate(PI / 4);"
      },
      {
        name: "scale()",
        syntax: "scale(s) or scale(x, y)",
        description: "Increases or decreases the size of objects.",
        example: "scale(2.0);"
      },
      {
        name: "push()",
        syntax: "push()",
        description: "Saves the current drawing style settings and transformations.",
        example: "push();\nrotate(PI/4);\nrect(0,0,50,50);\npop();"
      },
      {
        name: "pop()",
        syntax: "pop()",
        description: "Restores the previous drawing style settings and transformations.",
        example: "push();\ntranslate(50,50);\npop();"
      }
    ]
  },
  {
    title: "Input - Mouse",
    functions: [
      {
        name: "mouseX",
        syntax: "mouseX",
        description: "System variable that stores the current horizontal position of the mouse.",
        example: "ellipse(mouseX, 50, 20);"
      },
      {
        name: "mouseY",
        syntax: "mouseY",
        description: "System variable that stores the current vertical position of the mouse.",
        example: "ellipse(50, mouseY, 20);"
      },
      {
        name: "pmouseX",
        syntax: "pmouseX",
        description: "System variable that stores the previous horizontal position of the mouse.",
        example: "line(pmouseX, pmouseY, mouseX, mouseY);"
      },
      {
        name: "pmouseY",
        syntax: "pmouseY",
        description: "System variable that stores the previous vertical position of the mouse.",
        example: "line(pmouseX, pmouseY, mouseX, mouseY);"
      },
      {
        name: "mouseIsPressed",
        syntax: "mouseIsPressed",
        description: "Variable that is true if any mouse button is pressed, false otherwise.",
        example: "if (mouseIsPressed) {\n  ellipse(mouseX, mouseY, 20);\n}"
      },
      {
        name: "mousePressed()",
        syntax: "function mousePressed() { }",
        description: "Called once after every time a mouse button is pressed.",
        example: "function mousePressed() {\n  background(220);\n}"
      },
      {
        name: "mouseClicked()",
        syntax: "function mouseClicked() { }",
        description: "Called once after a mouse button has been pressed and released.",
        example: "function mouseClicked() {\n  ellipse(mouseX, mouseY, 50);\n}"
      }
    ]
  },
  {
    title: "Input - Keyboard",
    functions: [
      {
        name: "key",
        syntax: "key",
        description: "System variable that stores the most recent key pressed.",
        example: "if (key === 'a') {\n  // do something\n}"
      },
      {
        name: "keyCode",
        syntax: "keyCode",
        description: "System variable that stores the numeric key code of the last key pressed.",
        example: "if (keyCode === UP_ARROW) {\n  // do something\n}"
      },
      {
        name: "keyIsPressed",
        syntax: "keyIsPressed",
        description: "Variable that is true if any key is pressed, false otherwise.",
        example: "if (keyIsPressed) {\n  line(20, 20, 80, 80);\n}"
      },
      {
        name: "keyPressed()",
        syntax: "function keyPressed() { }",
        description: "Called once every time a key is pressed.",
        example: "function keyPressed() {\n  background(220);\n}"
      }
    ]
  },
  {
    title: "Typography",
    functions: [
      {
        name: "text()",
        syntax: "text(str, x, y)",
        description: "Draws text to the screen.",
        example: "text('Hello!', 10, 30);"
      },
      {
        name: "textSize()",
        syntax: "textSize(size)",
        description: "Sets the current font size.",
        example: "textSize(32);"
      },
      {
        name: "textAlign()",
        syntax: "textAlign(horizAlign, vertAlign)",
        description: "Sets the current alignment for drawing text.",
        example: "textAlign(CENTER, CENTER);"
      },
      {
        name: "textFont()",
        syntax: "textFont(font)",
        description: "Sets the current font.",
        example: "textFont('Helvetica');"
      },
      {
        name: "loadFont()",
        syntax: "loadFont(path)",
        description: "Loads an OpenType font file and returns a font object.",
        example: "font = loadFont('font.otf');"
      }
    ]
  },
  {
    title: "Math",
    functions: [
      {
        name: "random()",
        syntax: "random(min, max)",
        description: "Generates random numbers.",
        example: "let x = random(0, 100);"
      },
      {
        name: "noise()",
        syntax: "noise(x, y, z)",
        description: "Returns Perlin noise value at specified coordinates.",
        example: "let n = noise(0.1, 0.2);"
      },
      {
        name: "map()",
        syntax: "map(value, start1, stop1, start2, stop2)",
        description: "Re-maps a number from one range to another.",
        example: "let x = map(mouseX, 0, width, 0, 100);"
      },
      {
        name: "constrain()",
        syntax: "constrain(value, min, max)",
        description: "Constrains a value between a minimum and maximum value.",
        example: "let x = constrain(mouseX, 50, 350);"
      },
      {
        name: "dist()",
        syntax: "dist(x1, y1, x2, y2)",
        description: "Calculates the distance between two points.",
        example: "let d = dist(mouseX, mouseY, width/2, height/2);"
      },
      {
        name: "lerp()",
        syntax: "lerp(start, stop, amt)",
        description: "Calculates a number between two numbers at a specific increment.",
        example: "let x = lerp(0, 100, 0.5);"
      }
    ]
  },
  {
    title: "Constants",
    functions: [
      {
        name: "PI",
        syntax: "PI",
        description: "The mathematical constant π (3.14159...).",
        example: "rotate(PI);"
      },
      {
        name: "TWO_PI",
        syntax: "TWO_PI",
        description: "TWO_PI is a mathematical constant with the value 6.28318...",
        example: "arc(50, 50, 80, 80, 0, TWO_PI);"
      },
      {
        name: "HALF_PI",
        syntax: "HALF_PI",
        description: "HALF_PI is a mathematical constant with the value 1.57079...",
        example: "arc(50, 50, 80, 80, 0, HALF_PI);"
      },
      {
        name: "QUARTER_PI",
        syntax: "QUARTER_PI",
        description: "QUARTER_PI is a mathematical constant with the value 0.78539...",
        example: "rotate(QUARTER_PI);"
      }
    ]
  },
  {
    title: "Image",
    functions: [
      {
        name: "loadImage()",
        syntax: "loadImage(path)",
        description: "Loads an image from a path and creates a p5.Image object.",
        example: "img = loadImage('image.jpg');"
      },
      {
        name: "image()",
        syntax: "image(img, x, y, width, height)",
        description: "Draws an image to the canvas.",
        example: "image(img, 0, 0, 100, 100);"
      },
      {
        name: "imageMode()",
        syntax: "imageMode(mode)",
        description: "Modifies the location from which images are drawn (CORNER or CENTER).",
        example: "imageMode(CENTER);"
      },
      {
        name: "tint()",
        syntax: "tint(color)",
        description: "Sets the fill value for displaying images.",
        example: "tint(255, 0, 0);"
      },
      {
        name: "noTint()",
        syntax: "noTint()",
        description: "Removes the current fill value for displaying images.",
        example: "noTint();"
      }
    ]
  },
  {
    title: "Vertex",
    functions: [
      {
        name: "beginShape()",
        syntax: "beginShape(kind)",
        description: "Begins recording vertices for a shape.",
        example: "beginShape();\nvertex(30, 20);\nvertex(85, 20);\nvertex(85, 75);\nendShape(CLOSE);"
      },
      {
        name: "endShape()",
        syntax: "endShape(mode)",
        description: "Stops recording vertices for a shape.",
        example: "endShape(CLOSE);"
      },
      {
        name: "vertex()",
        syntax: "vertex(x, y)",
        description: "Adds a vertex to a custom shape.",
        example: "vertex(30, 75);"
      },
      {
        name: "curveVertex()",
        syntax: "curveVertex(x, y)",
        description: "Adds a curved vertex to a shape.",
        example: "curveVertex(84, 91);"
      },
      {
        name: "bezierVertex()",
        syntax: "bezierVertex(x2, y2, x3, y3, x4, y4)",
        description: "Adds a bezier curve vertex to a shape.",
        example: "bezierVertex(25, 25, 75, 25, 75, 75);"
      }
    ]
  }
];

export function P5CheatSheet() {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredData = cheatSheetData.map(category => ({
    ...category,
    functions: category.functions.filter(func =>
      func.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      func.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.functions.length > 0);

  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="w-full h-full overflow-hidden flex flex-col bg-gradient-to-br from-blue-50 via-cyan-50 to-white">
      {/* Print Styles */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print-content, .print-content * {
            visibility: visible;
          }
          .print-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          .no-print {
            display: none !important;
          }
          @page {
            margin: 0.8cm;
            size: A4;
          }
          .print-layout {
            font-size: 9pt;
          }
          .print-layout h1 {
            font-size: 24pt;
            margin-bottom: 1rem;
            text-align: center;
            color: #0ea5e9;
          }
          .print-layout h2 {
            font-size: 14pt;
            margin-top: 1.5rem;
            margin-bottom: 0.8rem;
            color: #06b6d4;
            border-bottom: 2px solid #67e8f9;
            padding-bottom: 0.3rem;
            page-break-after: avoid;
          }
          .print-layout .func-card {
            break-inside: avoid;
            margin-bottom: 0.8rem;
            padding: 0.6rem;
            border: 1px solid #e5e7eb;
            border-left: 3px solid #0ea5e9;
            border-radius: 0.25rem;
            background: white;
          }
          .print-layout .func-name {
            font-size: 10pt;
            font-weight: bold;
            color: #0284c7;
            margin-bottom: 0.3rem;
            font-family: monospace;
          }
          .print-layout .func-syntax {
            font-size: 8pt;
            background: #f0f9ff;
            padding: 0.3rem;
            margin-bottom: 0.3rem;
            font-family: monospace;
            border-radius: 0.15rem;
          }
          .print-layout .func-desc {
            font-size: 8.5pt;
            margin-bottom: 0.3rem;
            color: #374151;
          }
          .print-layout .func-example-label {
            font-size: 7pt;
            color: #6b7280;
            margin-bottom: 0.2rem;
          }
          .print-layout .func-example {
            font-size: 7.5pt;
            background: #f9fafb;
            padding: 0.3rem;
            font-family: monospace;
            white-space: pre-wrap;
            border: 1px solid #e5e7eb;
            border-radius: 0.15rem;
          }
          .print-layout .grid-print {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.8rem;
          }
        }
      `}</style>

      {/* Header */}
      <div className="border-b bg-white/80 backdrop-blur-sm no-print sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-sky-500 to-cyan-500 bg-clip-text text-transparent">
                p5.js Cheat Sheet
              </h1>
              <p className="text-gray-600 mt-2">
                Quick reference for creative coding
              </p>
            </div>
            <Button onClick={handleExportPDF} className="gap-2 bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600">
              <FileDown className="w-4 h-4" />
              Export to PDF
            </Button>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search functions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white"
            />
          </div>
        </div>
      </div>

      {/* Content - Single continuous layout */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto px-6 py-8 print-content">
          {/* For print view - pretty layout */}
          <div className="hidden print:block print-layout">
            <h1>p5.js Cheat Sheet</h1>
            {cheatSheetData.map((category) => (
              <div key={category.title}>
                <h2>{category.title}</h2>
                <div className="grid-print">
                  {category.functions.map((func) => (
                    <div key={func.name} className="func-card">
                      <div className="func-name">{func.name}</div>
                      <div className="func-syntax">{func.syntax}</div>
                      <div className="func-desc">{func.description}</div>
                      {func.example && (
                        <div>
                          <div className="func-example-label">Example:</div>
                          <div className="func-example">{func.example}</div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* For screen view - all categories in one continuous layout */}
          <div className="print:hidden space-y-10">
            {filteredData.map((category) => (
              <section key={category.title}>
                <h2 className="text-3xl font-bold text-cyan-600 mb-6 pb-2 border-b-2 border-cyan-200">
                  {category.title}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {category.functions.map((func) => (
                    <div 
                      key={func.name} 
                      className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-lg transition-shadow border-l-4 border-l-sky-500"
                    >
                      <h3 className="text-lg font-mono font-bold text-sky-600 mb-2">
                        {func.name}
                      </h3>
                      <div className="font-mono text-xs bg-blue-50 p-2 rounded mb-3 break-all">
                        {func.syntax}
                      </div>
                      <p className="text-sm text-gray-700 mb-3">
                        {func.description}
                      </p>
                      {func.example && (
                        <div className="bg-gray-50 p-3 rounded border border-gray-200">
                          <p className="text-xs text-gray-500 mb-1">Example:</p>
                          <pre className="text-xs font-mono text-gray-800 overflow-x-auto whitespace-pre-wrap">
                            {func.example}
                          </pre>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}