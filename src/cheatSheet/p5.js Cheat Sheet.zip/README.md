
  # p5.js Cheat Sheet

  This is a code bundle for p5.js Cheat Sheet. The original project is available at https://www.figma.com/design/TGpSLfeMlQUskyioHYvAy5/p5.js-Cheat-Sheet.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  